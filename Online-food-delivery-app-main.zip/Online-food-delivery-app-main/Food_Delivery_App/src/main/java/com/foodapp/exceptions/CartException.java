package com.foodapp.exceptions;

public class CartException extends Exception{
	
	public CartException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public CartException(String message){
		super(message);
	}

}
