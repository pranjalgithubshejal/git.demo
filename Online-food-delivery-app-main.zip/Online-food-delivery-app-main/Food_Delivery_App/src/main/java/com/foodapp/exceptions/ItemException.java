package com.foodapp.exceptions;

public class ItemException extends Exception {
	
	public ItemException() {
		// TODO Auto-generated constructor stub
	}
	

	public ItemException(String message) {
		super(message);
		
	}

}
