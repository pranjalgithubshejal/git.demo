package com.foodapp.authexceptions;

public class AuthorizationException extends Exception{
	
	
	public AuthorizationException() {
		// TODO Auto-generated constructor stub
	}
	
	
	public AuthorizationException(String message) {
		super(message);
	}

}
